function qs( s ){
    return document.querySelector(s);
}
