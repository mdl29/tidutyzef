function ClientJoueur( ){
	this.name;
	this.team;
	this.pos;
}
